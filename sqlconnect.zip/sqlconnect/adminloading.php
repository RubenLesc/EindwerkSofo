<?php
// Connect to the database
$con = mysqli_connect('localhost', 'root', '', 'eindwerksofo');

// Check connection
if (mysqli_connect_errno()) {
    echo "1: Connection failed"; // Error 1: Connection failed
    exit();
}

// SQL query to retrieve usernames, admin status, and coins from tblplayers
$sql = "SELECT Username, adminn, coins FROM tblplayers";
$result = mysqli_query($con, $sql);

$output = "";

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $output .= $row["Username"] . "," . $row["adminn"] . "," . $row["coins"] . ";";
    }
}

// Close database connection
mysqli_close($con);

// Output the usernames, admin statuses, and coins
echo rtrim($output, ";"); // Remove the last semicolon
?>
