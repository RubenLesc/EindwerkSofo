<?php
// Connect to the database
$con = new mysqli('localhost', 'root', '', 'eindwerksofo');

// Check connection
if ($con->connect_error) {
    die("1: Connection failed: " . $con->connect_error);
}

// Check if POST variables are set
if (!isset($_POST["name"]) || !isset($_POST["current_password"]) || !isset($_POST["new_password"]) || !isset($_POST["confirm_password"])) {
    die("2: Required fields are missing");
}

// Obtain username and passwords via POST
$username = $_POST["name"];
$current_password = $_POST["current_password"];
$new_password = $_POST["new_password"];
$confirm_password = $_POST["confirm_password"];

// Check if new password and confirm password match
if ($new_password !== $confirm_password) {
    echo "8: New password and confirmation do not match"; // Error 8: Passwords do not match
    exit();
}

// Check if the new password is at least 5 characters long
if (strlen($new_password) < 5) {
    echo "9: New password must be at least 5 characters long"; // Error 9: New password too short
    exit();
}

// Prepared statement to get the current user's data
$namecheckquery = $con->prepare("SELECT username, salt, hashh FROM tblplayers WHERE username = ?");
$namecheckquery->bind_param('s', $username);
$namecheckquery->execute();
$result = $namecheckquery->get_result();

if ($result->num_rows != 1) {
    echo "5: Either no user with name, or more than one"; // Error 5: User does not exist or multiple users found
    $namecheckquery->close();
    exit();
}

// Fetch the user's current data
$existinginfo = $result->fetch_assoc();
$salt = $existinginfo["salt"];
$hash = $existinginfo["hashh"];
$namecheckquery->close();

// Verify current password
$current_loginhash = crypt($current_password, $salt);
if ($hash != $current_loginhash) {
    echo "6: Incorrect current password"; // Error 6: Current password is incorrect
    exit();
}

// Generate new hash for the new password
$new_salt = "\$5\$rounds=5000\$" . "eindwerksofo" . $username . "\$";
$new_hash = crypt($new_password, $new_salt);

// Update the user's password in the database
$updatepasswordquery = $con->prepare("UPDATE tblplayers SET hashh = ?, salt = ? WHERE username = ?");
$updatepasswordquery->bind_param('sss', $new_hash, $new_salt, $username);

if (!$updatepasswordquery->execute()) {
    echo "7: Update password query failed: " . $updatepasswordquery->error; // Error 7: Update password query failed
    $updatepasswordquery->close();
    exit();
}
$updatepasswordquery->close();

// Password update successful
echo "0";

// Close database connection
$con->close();
?>
