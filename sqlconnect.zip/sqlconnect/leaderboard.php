<?php
// Connect to the database
$con = mysqli_connect('localhost', 'root', '', 'eindwerksofo');

// Check connection
if (mysqli_connect_errno()) {
    echo "1: Connection failed"; // Error 1: Connection failed
    exit();
}

// SQL query to retrieve top 5 player names and coins for level 1 from tblplayers and tblleaderboard using inner join
$sql_coins = "SELECT tblplayers.username, tblleaderboard.coins
              FROM tblleaderboard
              INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
              WHERE tblleaderboard.coins IS NOT NULL
              ORDER BY tblleaderboard.coins DESC
              LIMIT 5";

$result_coins = mysqli_query($con, $sql_coins);

// SQL query to retrieve top 5 player names and time for level 1 from tblplayers and tblleaderboard using inner join
$sql_time1 = "SELECT tblplayers.username, tblleaderboard.timelvl1
             FROM tblleaderboard
             INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
             WHERE tblleaderboard.timelvl1 IS NOT NULL
             ORDER BY CAST(tblleaderboard.timelvl1 AS UNSIGNED) ASC
             LIMIT 5";

$result_time1 = mysqli_query($con, $sql_time1);

// SQL query to retrieve top 5 player names and time for level 2 from tblplayers and tblleaderboard using inner join
$sql_time2 = "SELECT tblplayers.username, tblleaderboard.timelvl2
             FROM tblleaderboard
             INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
             WHERE tblleaderboard.timelvl2 IS NOT NULL
             ORDER BY CAST(tblleaderboard.timelvl2 AS UNSIGNED) ASC
             LIMIT 5";

$result_time2 = mysqli_query($con, $sql_time2);

// SQL query to retrieve top 5 player names and time for level 3 from tblplayers and tblleaderboard using inner join
$sql_time3 = "SELECT tblplayers.username, tblleaderboard.timelvl3
             FROM tblleaderboard
             INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
             WHERE tblleaderboard.timelvl3 IS NOT NULL
             ORDER BY CAST(tblleaderboard.timelvl3 AS UNSIGNED) ASC
             LIMIT 5";

$result_time3 = mysqli_query($con, $sql_time3);

// SQL query to retrieve top 5 player names and time for level 4 from tblplayers and tblleaderboard using inner join
$sql_time4 = "SELECT tblplayers.username, tblleaderboard.timelvl4
             FROM tblleaderboard
             INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
             WHERE tblleaderboard.timelvl4 IS NOT NULL
             ORDER BY CAST(tblleaderboard.timelvl4 AS UNSIGNED) ASC
             LIMIT 5";

$result_time4 = mysqli_query($con, $sql_time4);

$output_coins = "";
$output_time1 = "";
$output_time2 = "";
$output_time3 = "";
$output_time4 = "";

// Process coins data
if (mysqli_num_rows($result_coins) > 0) {
    $counter = 1;
    while ($row = mysqli_fetch_assoc($result_coins)) {
        $output_coins .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["coins"], ENT_QUOTES, 'UTF-8') . " coins\n \n";
        $counter++;
    }
} else {
    //this won't happen but it here for safety measures
    $output_coins = "No player coins found\n";
}

// Process time data for level 1
if (mysqli_num_rows($result_time1) > 0) {
    $counter = 1;
    while ($row = mysqli_fetch_assoc($result_time1)) {
        $output_time1 .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["timelvl1"], ENT_QUOTES, 'UTF-8') . " seconds\n \n";
        $counter++;
    }
} else {
    $output_time1 = "Be the first \nto beat level1!\n";
}

// Process time data for level 2
if (mysqli_num_rows($result_time2) > 0) {
    $counter = 1;
    while ($row = mysqli_fetch_assoc($result_time2)) {
        $output_time2 .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["timelvl2"], ENT_QUOTES, 'UTF-8') . " seconds\n \n";
        $counter++;
    }
} else {
    $output_time2 = "Be the first \nto beat level 2!\n";
}

// Process time data for level 3
if (mysqli_num_rows($result_time3) > 0) {
    $counter = 1;
    while ($row = mysqli_fetch_assoc($result_time3)) {
        $output_time3 .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["timelvl3"], ENT_QUOTES, 'UTF-8') . " seconds\n \n";
        $counter++;
    }
} else {
    $output_time3 = "Be the first \nto beat level 3!\n";
}

// Process time data for level 4
if (mysqli_num_rows($result_time4) > 0) {
    $counter = 1;
    while ($row = mysqli_fetch_assoc($result_time4)) {
        $output_time4 .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["timelvl4"], ENT_QUOTES, 'UTF-8') . " seconds\n \n";
        $counter++;
    }
} else {
    $output_time4 = "Be the first \nto beat level 4!\n";
}

// Close database connection
mysqli_close($con);

// Echo the combined output
echo "\n" . $output_coins . "Time Level 1\n" . $output_time1 . "Time Level 2\n" . $output_time2 . "Time Level 3\n" . $output_time3 . "Time Level 4\n" . $output_time4;
?>
