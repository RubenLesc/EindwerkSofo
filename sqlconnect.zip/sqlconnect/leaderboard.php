<?php
// Connect to the database
$con = mysqli_connect('localhost', 'root', '', 'eindwerksofo');

// Check connection
if (mysqli_connect_errno()) {
    echo "1: Connection failed"; // Error 1: Connection failed
    exit();
}

// SQL query to retrieve top 5 player names and coins for level 1 from tblplayers and tblleaderboard using inner join
$sql_coins = "SELECT tblplayers.username, tblleaderboard.coins
              FROM tblleaderboard
              INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
              WHERE tblleaderboard.coins IS NOT NULL
              ORDER BY tblleaderboard.coins DESC
              LIMIT 5";

$result_coins = mysqli_query($con, $sql_coins);

// SQL query to retrieve top 5 player names and time for level 1 from tblplayers and tblleaderboard using inner join
$sql_time = "SELECT tblplayers.username, tblleaderboard.timelvl1
             FROM tblleaderboard
             INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
             WHERE tblleaderboard.timelvl1 IS NOT NULL
             ORDER BY CAST(tblleaderboard.timelvl1 AS UNSIGNED) ASC
             LIMIT 5";

$result_time = mysqli_query($con, $sql_time);

$output_coins = "";
$output_time = "";

// Process coins data
if (mysqli_num_rows($result_coins) > 0) {
    $counter = 1;
    while($row = mysqli_fetch_assoc($result_coins)) {
        $output_coins .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["coins"], ENT_QUOTES, 'UTF-8') . " coins\n \n";
        $counter++;
    }
} else {
    $output_coins = "No player coins found\n";
}

// Process time data
if (mysqli_num_rows($result_time) > 0) {
    $counter = 1;
    while($row = mysqli_fetch_assoc($result_time)) {
        $output_time .= $counter . ". " . $row["username"] . ":\n    " . htmlspecialchars($row["timelvl1"], ENT_QUOTES, 'UTF-8') . " seconds\n \n";
        $counter++;
    }
} else {
    $output_time = "No player times found\n";
}

// Close database connection
mysqli_close($con);

// Echo the combined output
echo "Coins\n" . $output_coins . "Time\n" . $output_time;
?>
