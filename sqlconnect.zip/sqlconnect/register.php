<?php
// Connect to the database
$con = new mysqli('localhost', 'root', '', 'eindwerksofo');

// Check connection
if ($con->connect_error) {
    die("1: Connection failed: " . $con->connect_error);
}

// Check if POST variables are set
if (!isset($_POST["name"]) || !isset($_POST["password"])) {
    die("2: Required fields are missing");
}

// Obtain username and password via POST
$username = $_POST["name"];
$password = $_POST["password"];


// Prepared statement to check if username exists
$namecheckquery = $con->prepare("SELECT username FROM tblplayers WHERE username = ?");
//bind parameters with the questionmarks in the sqlstatement
$namecheckquery->bind_param('s', $username);
$namecheckquery->execute();
$namecheckquery->store_result();

if ($namecheckquery->num_rows > 0) {
    echo "3: Name already exists"; // Error 3: Name already exists
    $namecheckquery->close();
    exit();
}
$namecheckquery->close(); // Close the statement

// Insert user into database 
$salt = "\$5\$rounds=5000\$" . "eindwerksofo" . $username . "\$";
$hash = crypt($password, $salt);


$insertuserquery = $con->prepare("INSERT INTO tblplayers (username, hashh, salt) VALUES (?, ?, ?)");
//bind parameters with the questionmarks in the sqlstatement
$insert_salt = $salt;
$insertuserquery->bind_param('sss', $username, $hash, $insert_salt); 


if (!$insertuserquery->execute()) {
    echo "4: Insert player query failed: " . $insertuserquery->error; // Error 4: Insert player query failed
    $insertuserquery->close();
    exit();
}
$insertuserquery->close(); // Close the statement

// Get the ID of the newly inserted user
$new_user_id = $con->insert_id;

// Insert additional data into another table, using the new user's ID
$insertleaderboardquery = $con->prepare("INSERT INTO tblleaderboard (PlayerId) VALUES (?)");
$insertleaderboardquery->bind_param('i', $new_user_id);

if (!$insertleaderboardquery->execute()) {
    echo "5: Insert other data query failed: " . $insertleaderboardquery->error; // Error 5: Insert data into tblLeaderboard query failed
    $insertleaderboardquery->close();
    exit();
}
$insertleaderboardquery->close(); // Close the statement



// User registration successful
echo "0";

// Close database connection
$con->close();
?>

