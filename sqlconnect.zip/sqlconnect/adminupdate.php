<?php
// Connect to the database
$con = mysqli_connect('localhost', 'root', '', 'eindwerksofo');

// Check connection
if (mysqli_connect_errno()) {
    echo "1: Connection failed"; // Error 1: Connection failed
    exit();
}

// Retrieve parameters from Unity
$username = $_POST['username'];
$selectedOption = $_POST['selectedOption'];

if ($selectedOption == "Delete account") {
    // Delete the user from the database
    $sql = "DELETE FROM tblplayers WHERE Username = '$username'";
    $result = mysqli_query($con, $sql);
    
    // Check if the deletion was successful
    if ($result) {
        echo "0"; // Success
    } else {
        echo "3: Delete failed"; // Error 3: Delete failed
    }
} else if ($selectedOption == "Keep account") {
    // Retrieve additional parameters for update operation
    $newAdminStatus = $_POST['adminStatus'];
    $newCoins = $_POST['coins'];
    $newPassword = isset($_POST['newPassword']) ? $_POST['newPassword'] : null;

    // Base SQL query for updating admin status and coins
    $sql = "UPDATE tblplayers SET adminn = '$newAdminStatus', coins = '$newCoins'";

    // Check if a new password is provided and is at least 5 characters long
    if (!is_null($newPassword) && strlen($newPassword) >= 5) {
        // Generate new salt and hash for the new password
        $new_salt = "\$5\$rounds=5000\$" . "eindwerksofo" . $username . "\$";
        $new_hash = crypt($newPassword, $new_salt);
        
        // Add the password update to the SQL query
        $sql .= ", hashh = '$new_hash', salt = '$new_salt'";
    }

    // Complete the SQL query with the WHERE clause
    $sql .= " WHERE Username = '$username'";

    // Execute the SQL query
    $result = mysqli_query($con, $sql);

    // Check if the update was successful
    if ($result) {
        echo "0"; // Success
    } else {
        echo "2: Update failed"; // Error 2: Update failed
    }
}

// Close database connection
mysqli_close($con);
?>
