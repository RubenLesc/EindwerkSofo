<?php
// Connect to the database
$con = mysqli_connect('localhost', 'root', '', 'eindwerksofo');

// Check connection
if (mysqli_connect_errno()) {
    echo "1: Connection failed"; // Error 1: Connection failed
    exit();
}

// Get data via POST from Unity
$coins = $_POST["coins"];
$username = $_POST["username"];
$elapsedTime = $_POST["elapsedTime"];
$id = $_POST["id"];

// Prevent SQL injection
$coins = mysqli_real_escape_string($con, $coins);
$username = mysqli_real_escape_string($con, $username);
$elapsedTime = mysqli_real_escape_string($con, $elapsedTime);
$id = mysqli_real_escape_string($con, $id);

// Update coins in the tblplayers table
$updateQuery = "UPDATE tblplayers SET coins = '$coins' WHERE Username = '$username';";
$result1 = mysqli_query($con, $updateQuery);
if (!$result1) {
    echo "2: Update query failed"; // Error 2: Update query failed
    exit();
}

// Retrieve the current time for the player
$currentQuery = "SELECT timelvl1 FROM tblleaderboard WHERE playerid = '$id'";
$currentResult = mysqli_query($con, $currentQuery);
if ($currentResult) {
    $currentRow = mysqli_fetch_assoc($currentResult);
    $current_time = $currentRow['timelvl1'];

    // Check if the new elapsed time is better (lower) than the current time
    if ($current_time === null || $elapsedTime < $current_time) {
        // Update the time in the tblleaderboard table
        $updateQuery2 = "UPDATE tblleaderboard SET timelvl1 = '$elapsedTime' WHERE playerid = '$id'";
        $result2 = mysqli_query($con, $updateQuery2);
        if (!$result2) {
            echo "4: The second query update failed"; // Error 4: The second query update failed
            exit();
        }
    }
} else {
    echo "5: Failed to retrieve current time"; // Error 5: Failed to retrieve current time
    exit();
}

// Data saved successfully
echo "3: Data saved successfully";

// Close database connection
mysqli_close($con);
?>
