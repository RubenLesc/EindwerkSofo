<?php
// Connect to the database
$con = mysqli_connect('localhost', 'root', '', 'eindwerksofo');

// Check connection
if (mysqli_connect_errno()) {
    echo "1: Connection failed"; // Error 1: Connection failed
    exit();
}

// Check if the username and ID are set in the POST request
if(isset($_POST['username']) && isset($_POST['id'])) {
    // Sanitize input to prevent SQL injection
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $id = intval($_POST['id']);

    // SQL query to retrieve player times based on username and ID
    $sql = "SELECT tblleaderboard.timelvl1, tblleaderboard.timelvl2, tblleaderboard.timelvl3, tblleaderboard.timelvl4
             FROM tblleaderboard
             INNER JOIN tblplayers ON tblplayers.id = tblleaderboard.playerid
             WHERE tblplayers.username = '$username' AND tblplayers.id = $id";

    // Execute the query
    $result = mysqli_query($con, $sql);

    // Check if there are results
    if(mysqli_num_rows($result) > 0) {
        // Fetch the results
        $row = mysqli_fetch_assoc($result);
        $time_lvl1 = $row['timelvl1'];
        $time_lvl2 = $row['timelvl2'];
        $time_lvl3 = $row['timelvl3'];
        $time_lvl4 = $row['timelvl4'];

        // Function to calculate rank for a level
        function calculateRank($time, $level, $con) {
            if ($time !== null) {
                // Query to count the number of players with better times for the given level
                $sql_rank = "SELECT COUNT(*) AS rank FROM tblleaderboard WHERE $level < '$time' AND $level IS NOT NULL";
                $result_rank = mysqli_query($con, $sql_rank);
                $row_rank = mysqli_fetch_assoc($result_rank);
                return intval($row_rank['rank']) + 1; // Add 1 to get the actual rank
            } else {
                return "TBD"; // Return TBD if time is null
            }
        }

        // Calculate rank for each level
        $rank_lvl1 = calculateRank($time_lvl1, 'timelvl1', $con);
        $rank_lvl2 = calculateRank($time_lvl2, 'timelvl2', $con);
        $rank_lvl3 = calculateRank($time_lvl3, 'timelvl3', $con);
        $rank_lvl4 = calculateRank($time_lvl4, 'timelvl4', $con);

        // Format the response
        $response_lvl1 = "Level 1: " . ($time_lvl1 !== null ? "$time_lvl1 seconds (Ranked $rank_lvl1)" : "TBD");
        $response_lvl2 = "Level 2: " . ($time_lvl2 !== null ? "$time_lvl2 seconds (Ranked $rank_lvl2)" : "TBD");
        $response_lvl3 = "Level 3: " . ($time_lvl3 !== null ? "$time_lvl3 seconds (Ranked $rank_lvl3)" : "TBD");
        $response_lvl4 = "Level 4: " . ($time_lvl4 !== null ? "$time_lvl4 seconds (Ranked $rank_lvl4)" : "TBD");
        echo "$response_lvl1 | $response_lvl2 | $response_lvl3 | $response_lvl4";
    } else {
        echo "User not found or no data available";
    }
} else {
    echo "Username or ID not provided";
}

// Close database connection
mysqli_close($con);
?>
