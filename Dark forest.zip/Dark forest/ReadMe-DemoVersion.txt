Thank you for downloading the Demo Version of 'Cold Valleys' asset pack.

Demo Version License:-
  � You can only use these assets in non-commercial projects.
  � You can edit/modify these assets.
  � Selling/copying/distributing/sharing these assets is strictly prohibited, even after modifying/editing.

Follow me on Itch.io for upcoming projects.
https://spirit-warrior.itch.io/

If you liked this demo, then don't forget to try out the full version.

Visit the official page of Cold Valleys:
https://spirit-warrior.itch.io/cold-valleys-winter-themed-pixel-art-asset-pack